# AlphaGuard — Binance Agent OS Track A

> AI-powered crypto portfolio intelligence agent built for the Binance Agent OS Mini Hackathon.

AlphaGuard is a **read-only by default** agent that turns Binance market data and a user's portfolio into an explainable 24-hour risk brief.

It demonstrates an agentic workflow rather than a simple chatbot:

```text
User
  │
  ▼
Portfolio + market context
  │
  ▼
┌──────────────────────┐
│  AlphaGuard Agent    │
│  - market analyst    │
│  - risk engine       │
│  - thesis generator  │
│  - scenario engine   │
└──────────┬───────────┘
           │
           ▼
   Risk / opportunity brief
           │
           ▼
   Watch conditions
```

## What it does

- Pulls live public Binance spot market data.
- Computes 24h return, volatility proxy, momentum, and volume regime.
- Scores portfolio concentration and asset-level risk.
- Produces bullish / neutral / bearish scenarios.
- Creates explicit **invalidation conditions** instead of pretending the future is known.
- Stores a compact audit trail for every analysis.
- Optionally calls an LLM to turn structured facts into a polished analyst brief.
- Includes an **Agent OS / MCP bridge** so the same workflow can consume tools exposed by a compatible Binance Agent OS MCP endpoint.
- Does **not** place live orders by default.

## Why this is a strong Track A demo

Binance says Agent OS connects AI agents to trading, market data, wallets and payments, with permissions that can be controlled and revoked. The official hackathon announcement says Track A rewards the best agent built with Agent OS. AlphaGuard focuses on the Data & Analysis workflow shown in the hackathon creative while leaving execution behind an explicit human-approval boundary.

Official hackathon information:
https://www.binance.com/en/square/post/362885563835358

## Quick start

### 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/alphaguard-agent-os.git
cd alphaguard-agent-os
```

### 2. Create environment

Python 3.11+ is recommended.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

### 3. Configure

```bash
cp .env.example .env
```

The app works without Binance API keys because it uses public market endpoints for demo data.

Optional LLM configuration:

```env
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5-mini
```

Optional Agent OS MCP configuration:

```env
BINANCE_AGENT_OS_MCP_URL=https://agent.binance.com/mcp/agentic
BINANCE_AGENT_OS_BEARER_TOKEN=
```

The exact authentication method and permissions are controlled by Binance Agent OS. Do not paste a production secret into GitHub.

### 4. Run

```bash
streamlit run app.py
```

Open the local URL shown by Streamlit.

### 5. Run tests

```bash
pytest
```

## Demo flow

Use this exact 90–120 second flow for the hackathon video:

1. Open AlphaGuard.
2. Show a portfolio with BTC, ETH and BNB.
3. Click **Analyze portfolio**.
4. Show the agent collecting market facts.
5. Show concentration and volatility findings.
6. Open **Scenarios**.
7. Show explicit conditions:
   - Bullish: positive momentum + healthy volume.
   - Neutral: range-bound conditions.
   - Bearish: momentum deterioration + elevated volatility.
8. Ask the agent:
   > "What would invalidate your current thesis?"
9. Show the answer and the watch conditions.
10. End with the audit trail and the read-only safety boundary.

## Architecture

```text
                  ┌────────────────────┐
                  │ Streamlit UI       │
                  └─────────┬──────────┘
                            │
                            ▼
                  ┌────────────────────┐
                  │ AlphaGuard Agent   │
                  └──────┬───────┬─────┘
                         │       │
              ┌──────────┘       └──────────┐
              ▼                             ▼
     ┌────────────────┐            ┌────────────────┐
     │ Binance public │            │ Agent OS / MCP │
     │ market adapter │            │ adapter        │
     └───────┬────────┘            └───────┬────────┘
             │                             │
             └──────────────┬──────────────┘
                            ▼
                   ┌─────────────────┐
                   │ Risk + Scenario │
                   │ engine          │
                   └────────┬────────┘
                            ▼
                   ┌─────────────────┐
                   │ Optional LLM    │
                   │ narrative layer │
                   └─────────────────┘
```

## Agent OS / MCP

`src/alphaguard/agent_os.py` contains a small Streamable HTTP MCP client. It can:

- initialize an MCP session;
- list tools;
- call tools;
- parse JSON or SSE responses;
- pass market-data requests through a compatible Agent OS MCP endpoint.

Because MCP authentication is environment-specific, AlphaGuard does not hard-code credentials.

Example configuration:

```env
BINANCE_AGENT_OS_MCP_URL=https://agent.binance.com/mcp/agentic
BINANCE_AGENT_OS_BEARER_TOKEN=YOUR_TOKEN
```

If the MCP endpoint is unavailable, the app falls back to Binance's public REST market data adapter. This makes the repository reproducible for judges while preserving the Agent OS integration path.

## Safety model

AlphaGuard is deliberately read-only:

- no private keys in the repository;
- no automatic order execution;
- no withdrawal functionality;
- no trading permission required for the demo;
- structured facts are generated before any optional LLM narration;
- the UI labels model-generated text separately from quantitative findings.

If you extend this into execution, keep order placement behind an explicit approval gate and least-privilege permissions.

## Project structure

```text
alphaguard-agent-os/
├── app.py
├── pyproject.toml
├── .env.example
├── Dockerfile
├── README.md
├── src/
│   └── alphaguard/
│       ├── agent.py
│       ├── agent_os.py
│       ├── binance.py
│       ├── config.py
│       ├── llm.py
│       ├── models.py
│       ├── risk.py
│       └── scenarios.py
├── tests/
│   ├── test_agent.py
│   ├── test_risk.py
│   └── test_scenarios.py
└── .github/workflows/test.yml
```

## Disclaimer

This software is a hackathon prototype for research and demonstration. It is not investment advice and does not guarantee trading results. Cryptoassets are volatile and can lose value. Availability of Binance products and Agent OS features depends on jurisdiction, account permissions and Binance's current terms.
